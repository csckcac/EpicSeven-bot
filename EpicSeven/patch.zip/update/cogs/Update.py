import discord
from discord.ext import commands
from core.classes import Cog_Extension
import update

class Update(Cog_Extension) :
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
    @commands.command()
    async def update_(self, ctx) :
        try :
            await update.update_bot()
            await ctx.send("bot has updated successfully")
        except Exception as e :
            await ctx.send(e)

async def setup(bot) :
    await bot.add_cog(Update(bot))